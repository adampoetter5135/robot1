import javax.swing.JOptionPane;

// Instead of hard-coding numbers into each of the loops I've used
// variables to keep track of how the arm is to be moved when moving
// blocks.

// This is by no means the only way of achieving the minimum number of
// moves for the robot - it is intended as an example only and it was not
// used as a guide when the assignments were marked. 

class RobotControl {
	private Robot r;

	public RobotControl(Robot r) {
		this.r = r;
		if (Robot.assessment == true) {

			r.speedUp(5);
		}
	}

	public void control(int barHeights[], int blockHeights[]) {

		controlMechanism(barHeights, blockHeights);

	}


	public void controlMechanism(int barHeights[], int blockHeights[]) {

		int h = 2; // Initial height of arm 1
		int w = 1; // Initial width of arm 2
		int d = 0; // Initial depth of arm 3

		int currentBlock = 1;
		int clearence = 0;

		int targetColumn = 3;
		int currentBar = 0;

		int targetCol1Ht = 0; // Applicable only for part (c) - Initially empty
		int targetCol2Ht = 0; // Applicable only for part (c) - Initially empty
		// Checks largest block
		// int maxBlock = 0;
		// for(int i = 0; i < blockHeights.length; i++) {
		// if(blockHeights[i] > maxBlock) {
		// maxBlock = blockHeights[i];
		// //System.out.println("largest block is " + maxBlock);
		// }
		// }

		// check largest bar
		int maxBar = 0;
		for (int i = 0; i < barHeights.length; i++) {
			if (barHeights[i] > maxBar) {
				maxBar = barHeights[i];
				// System.out.println("largest bar is " + maxBar);
			}
		}
		int maxRemainingBar = 0;
		int maxColumn = maxBar; // the highest value of bars plus the height of
								// the block if it is placed on it, at start of
								// program no blocks are placed on bars
		while (currentBlock <= blockHeights.length) {
			int sourceHt = 0;
			for (int i = 0; i <= blockHeights.length - currentBlock; i++) {//gets initial sorceHt value
				sourceHt += blockHeights[i];
			}


			int blockHt = blockHeights[blockHeights.length - currentBlock];

			// clearance should be based on the bars, the blocks placed on them,
			// the height of source blocks and the height of current block

			// Initially clearance will be determined by the blocks at source
			// (3+3+3+3=12)
			// as they are higher than any bar and block-height combined

			


			// checks if highest obstacle will potentially be the block plus the
			// bar
			if (sourceHt > maxColumn) {
				clearence = sourceHt;
				System.out.println("sourceHt > maxBlock + maxBar");
				System.out.println("clearence ...:" + clearence);
			}
		
			else {
				clearence = maxColumn;
				System.out.println("clearence = maxBlock + maxBar");
				System.out.println("clearence ...:" + clearence);
			}

			// this makes sure robot goes high enough to clear any obstacles
			while (h < clearence + 1) {
				// Raising 1
				r.up();

				// Current height of arm1 being incremented by 1
				h++;
			}

			// this will need to be updated each time a block is dropped off
			int Amt = 10;

			// Bring arm 2 to column 10
			while (w < Amt) {
				// moving 1 step horizontally
				r.extend();

				// Current width of arm2 being incremented by 1
				w++;
			}

			// lowering third arm - the amount to lower is based on current
			// height
			// and the top of source blocks

			// the position of the picker (bottom of third arm) is determined by
			// h and d
			while (h - d > sourceHt + 1) {
				// lowering third arm
				r.lower();

				// current depth of arm 3 being incremented
				d++;
			}

			// picking the topmost block
			r.pick();

			// topmost block is assumed to be 3 for parts (a) and (b)
			// blockHt = 3;

			// When you pick the top block height of source decreases
			// sourceHt -= blockHt;

			// raising third arm all the way until d becomes high enough to
			// clear the biggest block
			if (blockHt < 3) {
				while (h - d <= maxColumn + blockHt)//
				{
					r.raise();
					d--;
				}
			}

			

			else {
				while (h - d <= maxRemainingBar + blockHt)//

				{
					r.raise();
					d--;
				}
				
			}

			if (blockHt == 1) {
				while (w > 1) {
					r.contract();
					w--;

				}

			} else if (blockHt == 2) {							//moves block to target column depending on the block height
				while (w > 2) {
					r.contract();
					w--;

				}

			} else {

				while (w > targetColumn) {
					r.contract();
					w--;

				}
				targetColumn++;
			}

			// You need to lower the third arm so that the block sits just above
			// the bar
			// For part (a) all bars are initially set to 7
			// For Parts (b) and (c) you must extract this value from the array
			// barHeights
			// System.out.println("clearence is" + clearence);
			// for(int currentBar = 0; currentBar < barHeights.length -
			// barHeights.length ; currentBar++)

			// lowering third arm
			if (blockHt == 1) {
				while (h - d - blockHt > targetCol1Ht + 1) {
					r.lower();
					d++;

				}
				targetCol1Ht++;
			} else if (blockHt == 2) {
				while (h - d - blockHt > targetCol2Ht + 1) {
					r.lower();
					d++;

				}
				targetCol2Ht += 2;
				
			} else {
				while ((h - 1) - d - blockHt > barHeights[currentBar])

				{
					r.lower();
					d++;
				}
				
				for (int i = 0; i < barHeights.length; i++) {
					if (barHeights[currentBar] + blockHt > maxColumn) {
						maxColumn = barHeights[i] + blockHt;
					}
				}
			

			}

			// dropping the block
			r.drop();

			// The height of currentBar increases by block just placed
			// raising arm again
			sourceHt = sourceHt - blockHt;

			if (sourceHt > maxColumn) {
				clearence = sourceHt;
			} else {
				clearence = maxColumn;
			}
			if (blockHt == 3) {
				maxRemainingBar = 0;
				for (int i = currentBar + 1; i < barHeights.length - 1; i++) {

					if (barHeights[i] > maxRemainingBar) {
						clearence = barHeights[i];
						maxRemainingBar = barHeights[i];
						System.out.println("height of danger bar is " + barHeights[i]);
					}
					// else{maxRemainingBar = barHeights[currentBar];}
				}

				if (sourceHt > maxRemainingBar) {
					clearence = sourceHt;
				}

				currentBar++;
			}

			System.out.println("danger zone clearence = " + clearence);
			// raising the third arm clear of obstacles

			if (currentBlock == blockHeights.length) {
				break;
			}

			while (h - d <= clearence) {
				r.raise();
				d--;
			}

			currentBlock++;

		}
	}
}
